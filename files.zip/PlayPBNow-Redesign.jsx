import { useState } from "react";

const screens = ["Login", "Groups", "Setup", "Match", "Podium"];

// Modern color system
const c = {
  bg: "#0a0e1a",
  surface: "#131829",
  surfaceLight: "#1a2038",
  card: "#1e2540",
  cardHover: "#252d4a",
  accent: "#00e87b",
  accentGlow: "rgba(0, 232, 123, 0.15)",
  accentSoft: "rgba(0, 232, 123, 0.08)",
  secondary: "#6c5ce7",
  gold: "#ffd23f",
  silver: "#c0c7d6",
  bronze: "#e8985a",
  text: "#ffffff",
  textMuted: "#6b7394",
  textSoft: "#9ba3c2",
  danger: "#ff4757",
  male: "#4facfe",
  female: "#f78ca2",
  border: "rgba(255,255,255,0.06)",
  glassBg: "rgba(255,255,255,0.03)",
  glassStroke: "rgba(255,255,255,0.08)",
};

const font = `'DM Sans', -apple-system, sans-serif`;
const fontDisplay = `'Outfit', 'DM Sans', sans-serif`;

function LoginScreen() {
  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", height: "100%", padding: 32,
      background: `radial-gradient(ellipse at 50% 0%, ${c.accentGlow} 0%, transparent 60%), ${c.bg}`,
    }}>
      {/* Logo */}
      <div style={{ marginBottom: 8 }}>
        <div style={{
          width: 80, height: 80, borderRadius: 24,
          background: `linear-gradient(135deg, ${c.accent}, #00c853)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: `0 16px 48px ${c.accentGlow}`,
        }}>
          <span style={{ fontSize: 40 }}>🏓</span>
        </div>
      </div>
      <h1 style={{
        fontFamily: fontDisplay, fontSize: 32, fontWeight: 800,
        color: c.text, letterSpacing: -1, margin: "16px 0 4px",
      }}>PLAY PB NOW</h1>
      <p style={{
        fontFamily: font, fontSize: 13, color: c.textMuted,
        letterSpacing: 3, textTransform: "uppercase", marginBottom: 48,
      }}>Match Tracking</p>

      {/* Phone Input */}
      <div style={{ width: "100%", maxWidth: 320 }}>
        <label style={{
          fontFamily: font, fontSize: 12, fontWeight: 600,
          color: c.textMuted, textTransform: "uppercase", letterSpacing: 1.5,
          display: "block", marginBottom: 10,
        }}>Phone Number</label>
        <div style={{
          background: c.surface, border: `1px solid ${c.glassStroke}`,
          borderRadius: 16, padding: "18px 20px", marginBottom: 24,
        }}>
          <span style={{
            fontFamily: font, fontSize: 22, fontWeight: 600,
            color: c.text, letterSpacing: 2,
          }}>(949) 735-9415</span>
        </div>

        <button style={{
          width: "100%", padding: "18px 0", borderRadius: 16, border: "none",
          background: `linear-gradient(135deg, ${c.accent}, #00c853)`,
          color: c.bg, fontFamily: fontDisplay, fontSize: 16, fontWeight: 800,
          letterSpacing: 1, cursor: "pointer",
          boxShadow: `0 8px 32px ${c.accentGlow}`,
        }}>SEND CODE</button>

        <p style={{
          fontFamily: font, fontSize: 12, color: c.textMuted,
          textAlign: "center", marginTop: 20, lineHeight: 1.6,
        }}>We'll send a 6-digit verification code via SMS</p>
      </div>
    </div>
  );
}

function GroupsScreen() {
  const groups = [
    { name: "Pickleheads", court: "Sun and Sail", city: "Lake Forest", players: 12, f: 6, m: 6 },
    { name: "Friday Crew", court: "Rancho Niguel Club", city: "Laguna Niguel", players: 8, f: 4, m: 4 },
    { name: "Mixer Madness", court: "Marguerite Pkwy", city: "Mission Viejo", players: 16, f: 8, m: 8 },
  ];

  return (
    <div style={{ height: "100%", background: c.bg, display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{
        padding: "48px 24px 20px",
        background: `linear-gradient(180deg, ${c.surfaceLight} 0%, ${c.bg} 100%)`,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{
              fontFamily: fontDisplay, fontSize: 28, fontWeight: 800,
              color: c.text, letterSpacing: -0.5, margin: 0,
            }}>Your Groups</h1>
            <p style={{
              fontFamily: font, fontSize: 12, color: c.textMuted,
              letterSpacing: 2, textTransform: "uppercase", margin: "6px 0 0",
            }}>3 groups · 36 players</p>
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: c.surface, border: `1px solid ${c.glassStroke}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, cursor: "pointer",
            }}>🔗</div>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: c.surface, border: `1px solid ${c.glassStroke}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, cursor: "pointer",
            }}>⚙️</div>
          </div>
        </div>
      </div>

      {/* Group Cards */}
      <div style={{ flex: 1, overflow: "auto", padding: "8px 20px 120px" }}>
        {groups.map((g, i) => (
          <div key={i} style={{
            background: c.card, borderRadius: 20, padding: "20px 22px",
            marginBottom: 14, border: `1px solid ${c.border}`,
            cursor: "pointer", transition: "all 0.2s",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h3 style={{
                  fontFamily: fontDisplay, fontSize: 20, fontWeight: 700,
                  color: c.text, margin: 0,
                }}>{g.name}</h3>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8 }}>
                  <span style={{ fontSize: 12 }}>📍</span>
                  <span style={{
                    fontFamily: font, fontSize: 13, fontWeight: 500,
                    color: c.accent,
                  }}>{g.court}</span>
                  <span style={{
                    fontFamily: font, fontSize: 12, color: c.textMuted,
                  }}>· {g.city}</span>
                </div>
              </div>
              <div style={{
                background: c.accentSoft, borderRadius: 12, padding: "8px 14px",
                display: "flex", alignItems: "center", gap: 6,
              }}>
                <span style={{ fontSize: 14 }}>👥</span>
                <span style={{
                  fontFamily: fontDisplay, fontSize: 16, fontWeight: 700, color: c.accent,
                }}>{g.players}</span>
              </div>
            </div>

            <div style={{
              display: "flex", gap: 16, marginTop: 14,
              paddingTop: 14, borderTop: `1px solid ${c.border}`,
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{
                  width: 8, height: 8, borderRadius: 4, background: c.male,
                }}/>
                <span style={{ fontFamily: font, fontSize: 12, color: c.textSoft }}>{g.m} Male</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{
                  width: 8, height: 8, borderRadius: 4, background: c.female,
                }}/>
                <span style={{ fontFamily: font, fontSize: 12, color: c.textSoft }}>{g.f} Female</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* FAB */}
      <div style={{
        position: "absolute", bottom: 32, left: 0, right: 0,
        display: "flex", justifyContent: "center",
      }}>
        <button style={{
          padding: "16px 40px", borderRadius: 50, border: "none",
          background: `linear-gradient(135deg, ${c.accent}, #00c853)`,
          color: c.bg, fontFamily: fontDisplay, fontSize: 15, fontWeight: 800,
          letterSpacing: 0.5, cursor: "pointer",
          boxShadow: `0 8px 40px ${c.accentGlow}`,
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <span style={{ fontSize: 20 }}>+</span> NEW GROUP
        </button>
      </div>
    </div>
  );
}

function SetupScreen() {
  const players = [
    { name: "Chip", gender: "M", wins: 12, losses: 3, pct: 80, verified: true },
    { name: "Thanh", gender: "M", wins: 10, losses: 5, pct: 67, verified: true },
    { name: "Karen", gender: "F", wins: 8, losses: 4, pct: 67, verified: false },
    { name: "Eileen", gender: "F", wins: 9, losses: 6, pct: 60, verified: true },
    { name: "Kevin", gender: "M", wins: 7, losses: 8, pct: 47, verified: false },
    { name: "Astrid", gender: "F", wins: 6, losses: 9, pct: 40, verified: false },
  ];

  return (
    <div style={{ height: "100%", background: c.bg, display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{
        padding: "48px 20px 16px",
        background: c.surfaceLight,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: c.surface, display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 16, cursor: "pointer",
          }}>←</div>
          <div style={{ flex: 1 }}>
            <h2 style={{
              fontFamily: fontDisplay, fontSize: 20, fontWeight: 800,
              color: c.text, margin: 0,
            }}>PICKLEHEADS</h2>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4 }}>
              <span style={{ fontSize: 10 }}>📍</span>
              <span style={{ fontFamily: font, fontSize: 11, color: c.accent }}>Sun and Sail · Lake Forest</span>
            </div>
          </div>
          <button style={{
            padding: "8px 20px", borderRadius: 10, border: "none",
            background: c.accent, color: c.bg,
            fontFamily: font, fontSize: 12, fontWeight: 700, cursor: "pointer",
          }}>SAVE</button>
        </div>
        <div style={{
          display: "flex", gap: 6,
          fontFamily: font, fontSize: 11, color: c.textMuted,
        }}>
          <span style={{
            background: c.accentSoft, color: c.accent, padding: "4px 10px",
            borderRadius: 6, fontWeight: 600,
          }}>6 Players</span>
          <span style={{
            background: "rgba(79,172,254,0.1)", color: c.male, padding: "4px 10px",
            borderRadius: 6, fontWeight: 600,
          }}>3 M</span>
          <span style={{
            background: "rgba(247,140,162,0.1)", color: c.female, padding: "4px 10px",
            borderRadius: 6, fontWeight: 600,
          }}>3 F</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div style={{ display: "flex", gap: 10, padding: "16px 20px" }}>
        <button style={{
          flex: 1, padding: "14px 0", borderRadius: 14, border: "none",
          background: `linear-gradient(135deg, ${c.accent}, #00c853)`,
          color: c.bg, fontFamily: fontDisplay, fontSize: 14, fontWeight: 700,
          cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        }}>🎮 CREATE MATCH</button>
        <button style={{
          flex: 1, padding: "14px 0", borderRadius: 14, border: `1px solid ${c.glassStroke}`,
          background: c.surface, color: c.textSoft,
          fontFamily: fontDisplay, fontSize: 14, fontWeight: 700, cursor: "pointer",
        }}>👥 ALL PLAYERS</button>
      </div>

      {/* Search Input */}
      <div style={{ padding: "0 20px 12px" }}>
        <div style={{
          display: "flex", gap: 10, alignItems: "center",
        }}>
          <div style={{
            flex: 1, background: c.surface, border: `1px solid ${c.glassStroke}`,
            borderRadius: 14, padding: "14px 16px",
            fontFamily: font, fontSize: 15, color: c.textMuted,
          }}>Search or add player...</div>
          <div style={{
            width: 48, height: 48, borderRadius: 14,
            background: c.male, display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 20, cursor: "pointer",
          }}>♂</div>
          <div style={{
            width: 48, height: 48, borderRadius: 14,
            background: c.card, border: `1px solid ${c.glassStroke}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, color: c.text, cursor: "pointer",
          }}>+</div>
        </div>
      </div>

      {/* Player List */}
      <div style={{ flex: 1, overflow: "auto", padding: "0 20px 100px" }}>
        {players.map((p, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 14,
            padding: "14px 16px", marginBottom: 8,
            background: c.card, borderRadius: 16,
            border: `1px solid ${c.border}`,
          }}>
            <div style={{ color: c.textMuted, fontSize: 16, cursor: "grab" }}>☰</div>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: p.gender === "M" ? "rgba(79,172,254,0.15)" : "rgba(247,140,162,0.15)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>{p.gender === "M" ? "👨" : "👩"}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  fontFamily: fontDisplay, fontSize: 16, fontWeight: 600, color: c.text,
                }}>{p.name}</span>
                {p.verified && <span style={{ fontSize: 12 }}>✓</span>}
              </div>
              <span style={{
                fontFamily: font, fontSize: 11, color: c.textMuted,
              }}>{p.wins}W-{p.losses}L · {p.pct}%</span>
            </div>
            <div style={{
              fontSize: 16, color: c.danger, cursor: "pointer", opacity: 0.5,
            }}>✕</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MatchScreen() {
  const rounds = [
    { games: [
      { t1: ["Chip", "Karen"], t2: ["Kevin", "Eileen"], s1: 11, s2: 8, court: 1 },
      { t1: ["Thanh", "Astrid"], t2: ["Ram", "Kim"], s1: 9, s2: 11, court: 2 },
    ]},
    { games: [
      { t1: ["Chip", "Eileen"], t2: ["Thanh", "Karen"], s1: 11, s2: 5, court: 1 },
      { t1: ["Kevin", "Kim"], t2: ["Astrid", "Ram"], s1: "", s2: "", court: 2 },
    ]},
  ];

  return (
    <div style={{ height: "100%", background: c.bg, display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{
        padding: "48px 20px 16px",
        background: `linear-gradient(180deg, ${c.surfaceLight} 0%, ${c.bg} 100%)`,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{
            fontFamily: fontDisplay, fontSize: 20, fontWeight: 800,
            color: c.text, margin: 0,
          }}>PICKLEHEADS</h2>
          <div style={{ display: "flex", gap: 10 }}>
            <button style={{
              padding: "8px 16px", borderRadius: 10, border: `1px solid ${c.glassStroke}`,
              background: c.surface, color: c.textSoft,
              fontFamily: font, fontSize: 11, fontWeight: 700, cursor: "pointer",
              display: "flex", alignItems: "center", gap: 6,
            }}>📤 SHARE</button>
            <button style={{
              padding: "8px 16px", borderRadius: 10, border: "none",
              background: c.accent, color: c.bg,
              fontFamily: font, fontSize: 11, fontWeight: 700, cursor: "pointer",
            }}>✓ FINISH</button>
          </div>
        </div>
        <p style={{
          fontFamily: font, fontSize: 11, color: c.textMuted, margin: "8px 0 0",
        }}>Feb 20, 2026 · 6 Rounds · 2 Courts</p>
      </div>

      {/* Rounds */}
      <div style={{ flex: 1, overflow: "auto", padding: "12px 16px 100px" }}>
        {rounds.map((round, ri) => (
          <div key={ri} style={{ marginBottom: 20 }}>
            <div style={{
              fontFamily: fontDisplay, fontSize: 12, fontWeight: 700,
              color: c.textMuted, letterSpacing: 2, textTransform: "uppercase",
              marginBottom: 10, paddingLeft: 4,
            }}>Round {ri + 1}</div>

            {round.games.map((game, gi) => (
              <div key={gi} style={{
                background: c.card, borderRadius: 18, padding: 18,
                marginBottom: 10, border: `1px solid ${c.border}`,
              }}>
                <div style={{
                  fontFamily: font, fontSize: 10, color: c.textMuted,
                  letterSpacing: 1.5, marginBottom: 12, textTransform: "uppercase",
                }}>Court {game.court}</div>

                <div style={{ display: "flex", alignItems: "center" }}>
                  {/* Team 1 */}
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: fontDisplay, fontSize: 15, fontWeight: 600, color: c.text }}>{game.t1[0]}</div>
                    <div style={{ fontFamily: font, fontSize: 13, color: c.textSoft, marginTop: 2 }}>{game.t1[1]}</div>
                  </div>

                  {/* Scores */}
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{
                      width: 48, height: 52, borderRadius: 12,
                      background: game.s1 !== "" && game.s1 > game.s2 ? c.accentSoft : c.surface,
                      border: `2px solid ${game.s1 !== "" && game.s1 > game.s2 ? c.accent : c.border}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontFamily: fontDisplay, fontSize: 22, fontWeight: 800,
                      color: game.s1 !== "" ? (game.s1 > game.s2 ? c.accent : c.text) : c.textMuted,
                    }}>{game.s1 !== "" ? game.s1 : "—"}</div>
                    <span style={{ fontFamily: font, fontSize: 12, color: c.textMuted }}>vs</span>
                    <div style={{
                      width: 48, height: 52, borderRadius: 12,
                      background: game.s2 !== "" && game.s2 > game.s1 ? c.accentSoft : c.surface,
                      border: `2px solid ${game.s2 !== "" && game.s2 > game.s1 ? c.accent : c.border}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontFamily: fontDisplay, fontSize: 22, fontWeight: 800,
                      color: game.s2 !== "" ? (game.s2 > game.s1 ? c.accent : c.text) : c.textMuted,
                    }}>{game.s2 !== "" ? game.s2 : "—"}</div>
                  </div>

                  {/* Team 2 */}
                  <div style={{ flex: 1, textAlign: "right" }}>
                    <div style={{ fontFamily: fontDisplay, fontSize: 15, fontWeight: 600, color: c.text }}>{game.t2[0]}</div>
                    <div style={{ fontFamily: font, fontSize: 13, color: c.textSoft, marginTop: 2 }}>{game.t2[1]}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function PodiumScreen() {
  const podium = [
    { name: "Eileen", w: 5, l: 1, pct: 83, diff: "+22", badge: "💠", rank: 1 },
    { name: "Chip", w: 5, l: 1, pct: 83, diff: "+18", badge: "💎", rank: 2 },
    { name: "Karen", w: 4, l: 2, pct: 67, diff: "+12", badge: "🔥", rank: 3 },
  ];

  const rest = [
    { name: "Thanh", w: 4, l: 2, pct: 67, diff: "+8", badge: "🔥" },
    { name: "Kevin", w: 3, l: 3, pct: 50, diff: "+2", badge: "" },
    { name: "Astrid", w: 2, l: 4, pct: 33, diff: "-6", badge: "" },
    { name: "Ram", w: 2, l: 4, pct: 33, diff: "-10", badge: "🦃" },
    { name: "Kim", w: 1, l: 5, pct: 17, diff: "-18", badge: "" },
    { name: "Devin", w: 1, l: 5, pct: 17, diff: "-28", badge: "" },
  ];

  const podiumColors = [c.gold, c.silver, c.bronze];
  const podiumHeights = [140, 110, 90];
  const podiumOrder = [1, 0, 2]; // silver, gold, bronze (visual order)

  return (
    <div style={{ height: "100%", background: c.bg, display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{
        padding: "48px 20px 8px",
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: c.surface, display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 16, cursor: "pointer",
        }}>🏠</div>
        <div style={{ textAlign: "center" }}>
          <h2 style={{
            fontFamily: fontDisplay, fontSize: 18, fontWeight: 800,
            color: c.accent, margin: 0, letterSpacing: 2,
          }}>RANKINGS</h2>
          <div style={{
            display: "flex", gap: 4, marginTop: 8, justifyContent: "center",
          }}>
            {["WINS", "WIN %", "DIFF"].map((s, i) => (
              <button key={i} style={{
                padding: "5px 14px", borderRadius: 8, border: "none",
                background: i === 1 ? "white" : c.surface,
                color: i === 1 ? c.bg : c.textMuted,
                fontFamily: font, fontSize: 10, fontWeight: 700, cursor: "pointer",
                letterSpacing: 0.5,
              }}>{s}</button>
            ))}
          </div>
        </div>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: c.surface, display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 16, cursor: "pointer",
        }}>👥</div>
      </div>

      {/* Session Selector */}
      <div style={{
        margin: "12px 20px", padding: "10px 16px", borderRadius: 12,
        background: c.surface, border: `1px solid ${c.border}`,
        textAlign: "center", cursor: "pointer",
      }}>
        <span style={{
          fontFamily: font, fontSize: 12, fontWeight: 600, color: c.textSoft,
        }}>Pickleheads - Feb 20, 2026 ▾</span>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "0 16px 40px" }}>
        {/* Podium */}
        <div style={{
          display: "flex", justifyContent: "center", alignItems: "flex-end",
          height: 240, marginBottom: 24, gap: 8,
        }}>
          {podiumOrder.map((idx) => {
            const p = podium[idx];
            const color = podiumColors[idx];
            const h = podiumHeights[idx];
            return (
              <div key={idx} style={{
                display: "flex", flexDirection: "column", alignItems: "center",
                width: "30%",
              }}>
                {idx === 0 && <span style={{ fontSize: 28, marginBottom: -4 }}>👑</span>}
                <div style={{
                  width: 52, height: 52, borderRadius: 16,
                  background: `rgba(${idx===0?'255,210,63':idx===1?'192,199,214':'232,152,90'}, 0.15)`,
                  border: `2px solid ${color}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontFamily: fontDisplay, fontSize: 22, fontWeight: 800, color: color,
                  marginBottom: 8,
                }}>{p.name[0]}</div>
                <span style={{
                  fontFamily: fontDisplay, fontSize: 13, fontWeight: 700, color: c.text,
                  marginBottom: 2,
                }}>{p.name} {p.badge}</span>
                <span style={{
                  fontFamily: font, fontSize: 11, color: c.textSoft,
                }}>{p.w}W-{p.l}L</span>
                <span style={{
                  fontFamily: font, fontSize: 11, color: color, fontWeight: 700,
                }}>{p.pct}%</span>
                <div style={{
                  width: "100%", height: h, marginTop: 8,
                  borderRadius: "12px 12px 0 0",
                  background: `linear-gradient(180deg, rgba(${idx===0?'255,210,63':idx===1?'192,199,214':'232,152,90'}, 0.2) 0%, rgba(${idx===0?'255,210,63':idx===1?'192,199,214':'232,152,90'}, 0.05) 100%)`,
                  border: `1px solid rgba(${idx===0?'255,210,63':idx===1?'192,199,214':'232,152,90'}, 0.3)`,
                  borderBottom: "none",
                  display: "flex", alignItems: "flex-start", justifyContent: "center",
                  paddingTop: 12,
                }}>
                  <span style={{
                    fontFamily: fontDisplay, fontSize: 28, fontWeight: 900,
                    color: color, opacity: 0.3,
                  }}>{p.rank}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Rest of Leaderboard */}
        {rest.map((p, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 14,
            padding: "14px 16px", marginBottom: 8,
            background: c.card, borderRadius: 16,
            border: `1px solid ${c.border}`,
          }}>
            <span style={{
              fontFamily: fontDisplay, fontSize: 16, fontWeight: 800,
              color: c.textMuted, width: 24, textAlign: "center",
            }}>{i + 4}</span>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  fontFamily: fontDisplay, fontSize: 16, fontWeight: 600, color: c.text,
                }}>{p.name}</span>
                {p.badge && <span style={{ fontSize: 14 }}>{p.badge}</span>}
              </div>
              <span style={{
                fontFamily: font, fontSize: 11, color: c.textMuted,
              }}>{p.w}W-{p.l}L · {p.diff} Diff</span>
            </div>
            <span style={{
              fontFamily: fontDisplay, fontSize: 20, fontWeight: 800,
              color: p.pct >= 50 ? c.accent : c.textMuted,
            }}>{p.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function PlayPBNowRedesign() {
  const [activeScreen, setActiveScreen] = useState(1);

  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      minHeight: "100vh", padding: "40px 20px",
      background: "#06080f",
      fontFamily: font,
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />

      <h1 style={{
        fontFamily: fontDisplay, fontSize: 36, fontWeight: 900,
        background: `linear-gradient(135deg, ${c.accent}, #4facfe)`,
        WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
        marginBottom: 8,
      }}>Play PB Now — UI Redesign</h1>
      <p style={{
        fontFamily: font, fontSize: 14, color: c.textMuted, marginBottom: 32,
      }}>Modern · Minimal · Premium feel</p>

      {/* Screen Switcher */}
      <div style={{
        display: "flex", gap: 6, marginBottom: 32,
        background: c.surface, padding: 6, borderRadius: 16,
      }}>
        {screens.map((s, i) => (
          <button key={i} onClick={() => setActiveScreen(i)} style={{
            padding: "10px 22px", borderRadius: 12, border: "none",
            background: activeScreen === i ? c.accent : "transparent",
            color: activeScreen === i ? c.bg : c.textMuted,
            fontFamily: fontDisplay, fontSize: 13, fontWeight: 700,
            cursor: "pointer", transition: "all 0.2s",
          }}>{s}</button>
        ))}
      </div>

      {/* Phone Frame */}
      <div style={{
        width: 390, height: 844, borderRadius: 44,
        background: c.bg, overflow: "hidden", position: "relative",
        boxShadow: `0 0 0 2px ${c.glassStroke}, 0 40px 120px rgba(0,0,0,0.6)`,
      }}>
        {/* Notch */}
        <div style={{
          position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)",
          width: 160, height: 34, borderRadius: "0 0 20px 20px",
          background: "#000", zIndex: 100,
        }}/>

        {activeScreen === 0 && <LoginScreen />}
        {activeScreen === 1 && <GroupsScreen />}
        {activeScreen === 2 && <SetupScreen />}
        {activeScreen === 3 && <MatchScreen />}
        {activeScreen === 4 && <PodiumScreen />}
      </div>
    </div>
  );
}
