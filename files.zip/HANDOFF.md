# PLAY PB NOW — Project Handoff Document
## Date: Feb 17, 2026

---

## APP OVERVIEW

**Play PB Now!** is a React Native (Expo) pickleball match tracking app. Users create groups of players, generate round-robin match schedules, score games in real-time (including collaborative scoring across two devices), and save results. Players are universal — one record per real person tracked across all groups and courts.

**Tech Stack:** React Native + TypeScript (Expo Router), PHP backend, MySQL (MariaDB), hosted at `https://peoplestar.com/Chipleball/api/`

---

## CURRENT STATUS — What's Done vs What Needs Testing

### ✅ COMPLETED & DEPLOYED
1. **User authentication** — Phone number + Twilio SMS verification, session-based
2. **Groups system** — Create/edit/delete groups, each tied to a home court
3. **Collaborative scoring** — Unit A (host) creates session, Unit B joins via code, scores sync bidirectionally via polling
4. **Smart scoring** — Handles score entry intelligently (21-point games, auto-advance)
5. **Match saving** — Duplicate detection with hash comparison, force-update option

### 🔄 JUST BUILT — NEEDS DEPLOYMENT & TESTING
These files were built in this session and are in `/mnt/user-data/outputs/`:

**Universal Player Architecture:**
- Players are global — one record per real person, tracked across ALL groups/courts
- Phone number = optional unique identifier for verified players
- Groups now require a home court (court_id)
- Adding players searches globally first, then creates if not found
- Merge tool for combining duplicate player records

**Files ready to deploy:**

| File | Type | Description |
|------|------|-------------|
| `groups.tsx` | Frontend | Court picker in create-group modal (Step 1: Court → Step 2: Name), court shown on cards |
| `setup.tsx` | Frontend | Global player search, optional phone input with info popup, court from group params |
| `game.tsx` | Frontend | Collab scoring, save with duplicate detection, circular JSON fix |
| `useCollaborativeScoring.ts` | Hook | Unit A pushes all scores, Unit B pulls from server, polling after initial sync |
| `useSmartScoring.ts` | Hook | Returns ScoreChangeResult with changed flag and final values |
| `create_group.php` | Backend | Saves court_id with group |
| `get_groups.php` | Backend | Uses memberships table for player counts, returns court name |
| `add_player.php` | Backend | Universal players, NULL phone (no unique collision), links existing or creates new |
| `search_players.php` | Backend | Global search across ALL players with stats and group memberships |
| `merge_players.php` | Backend | Merges two player records — combines match history, transfers memberships |
| `get_players.php` | Backend | Returns stats (W/L/diff/win%) and home court |
| `save_players.php` | Backend | Saves drag-drop order_index to player_group_memberships |
| `get_courts.php` | Backend | Returns all courts for selection |
| `save_scores.php` | Backend | Duplicate detection + auto-recalculates player stats after save |
| `update_player_stats.php` | Backend | Standalone stats recalculator |
| `purge_data.php` | Backend | Cleans all tables except players, courts, users |
| `collab_sync_scores.php` | Backend | Stores s1_str/s2_str string values |
| `collab_get_scores.php` | Backend | Returns s1_str/s2_str in updates |
| `ShareMatchModal.tsx` | Component | Creates collab session, shows invite code |
| `JoinMatchModal.tsx` | Component | Joins collab session by code |
| `ScoreUpdateToast.tsx` | Component | Shows sync notifications |

**SQL migrations (already run):**
- `court_id` column added to `groups` table ✅
- `scores_hash` column added to `sessions` table ✅
- `s1_str`/`s2_str` columns added to `collab_score_updates` ✅
- All player/match data purged for fresh start ✅

---

## DATABASE SCHEMA

### `users`
- id, phone_number (unique), is_verified, created_at, updated_at, session_token, session_expires

### `groups`
- id, group_key (unique), name, **court_id** (FK→courts), device_id, owner_user_id (FK→users), created_at, updated_at

### `courts`
- id, name, city, state, address, created_by_device_id, created_at, created_by_user_id
- Currently has ~16 courts (Sun and Sail, The Club at Rancho Niguel, etc.)

### `players` (UNIVERSAL — one record per real person)
- id, group_id, player_key, first_name, last_name, cell_phone (unique, nullable), is_verified, gender, home_court_id (FK→courts), created_by_device_id, order_index, device_id, wins, losses, diff, win_pct, created_at, updated_at

### `player_group_memberships` (links players to groups)
- id, player_id (FK→players), group_id (FK→groups), order_index, joined_at

### `sessions` (saved matches)
- id, group_id, batch_id, share_code, title, device_id, user_id, session_date, created_at, player_count, male_count, female_count, scores_hash

### `matches` (individual games within sessions)
- id, group_id, session_id, batch_id, p1_key, p2_key, p3_key, p4_key, p1_name, p2_name, p3_name, p4_name, s1, s2, timestamp, match_date, device_id, round_num, court_num, match_title, created_at, updated_at

### `collab_sessions`
- id, session_code (unique), host_device_id, host_user_id, group_key, group_name, schedule_json, status, created_at, expires_at

### `collab_participants`
- id, session_id (FK), device_id, user_id, role (host/collaborator), joined_at

### `collab_score_updates`
- id, session_id (FK), round_idx, game_idx, s1, s2, s1_str, s2_str, updated_at
- Unique on (session_id, round_idx, game_idx)

### Other tables
- `round_byes`, `reports`, `sms_verifications`, `verification_codes`, `feature_access`, `payment_transactions`, `subscriptions`, `user_sessions`

---

## ARCHITECTURE — KEY DESIGN DECISIONS

### 1. Unit A is Boss (Collaborative Scoring)
- Server's `collab_score_updates` table is single source of truth
- Unit A creates session → pushes ALL current scores to server
- Unit B joins → FULL PULL from server (since=0) → replaces local state entirely
- Both poll every 3s, never overwrite locally-changed keys (4s protection window)
- Empty string = no value entered (NOT zero)
- `changed: false` in ScoreChangeResult means "user still typing, don't sync yet"

### 2. Universal Players
- One player record per real person
- Players link to groups via `player_group_memberships` table
- Phone number is optional unique identifier — NULL doesn't collide in unique index
- When adding a player to a group: search globally first → link if found → create if new
- New players inherit group's court as home_court_id
- Stats (wins/losses/diff/win_pct) accumulate from ALL matches across all groups

### 3. Score Saving
- `save_scores.php` checks for existing session with same group_id + session_date + title
- Same scores hash → "already exists" (no save)
- Different hash → offers force_update
- After saving, auto-recalculates stats for all involved players

### 4. App Navigation (Expo Router, tab-based)
```
/login → Phone verification
/(tabs)/groups → Group list (home screen)
/(tabs)/setup → Player roster + match config for selected group
/(tabs)/game → Active match scoring
/(tabs)/players → Global player management
```

---

## WHAT STILL NEEDS TO BE DONE

### Immediate (deploy & test what was just built)
1. Upload all PHP files to server
2. Replace frontend files (groups.tsx, setup.tsx, game.tsx, hooks, components)
3. Test the full flow: create group with court → add players → generate match → score → save
4. Test collaborative scoring end-to-end

### Next Features Requested by User
1. **FULL UI REDESIGN — HIGHEST PRIORITY** — Implement modern premium UI across all screens (Login, Groups, Setup, Match, Podium/Leaderboard). Key requirements:
   - **Dark theme**: Deep navy/black background (#0a0e1a), green accent (#00e87b), glass-like cards, clean typography using Outfit + DM Sans fonts
   - **Light theme**: Clean white/light opposite of dark theme — same layout, inverted colors
   - **Theme toggle**: User can switch between dark and light mode (persist choice in AsyncStorage)
   - **NO ping-pong paddle emoji (🏓) anywhere** — replace ALL instances with the actual logo image at `images/PlayPBNow-Logo-SMALL.png` (API_URL + path)
   - Reference artifact: `PlayPBNow-Redesign.jsx` was created showing the dark theme mockup for all 5 screens
   - Design pillars: minimal formatting, premium feel, rounded cards with subtle borders, accent glow effects, proper spacing
   - Apply to: login.tsx, groups.tsx, setup.tsx, game.tsx, leaderboard.tsx, tabs _layout.tsx
2. **Collab auto-navigate to podium on finish** — When Unit A clicks "Finish & Save" and confirms, ALL connected Unit B devices should automatically navigate to the podium/leaderboard page. Implementation plan:
   - `save_scores.php` or a new endpoint: after successful save, update `collab_sessions.status` to `"completed"` and store the `group_name` in the session
   - `collab_get_scores.php`: return the session `status` field in every poll response
   - `useCollaborativeScoring.ts`: in the polling loop, check if `status === "completed"` → if so, stop polling and trigger navigation
   - `game.tsx`: when collab hook signals completion, auto-navigate to `/(tabs)/leaderboard` with the group name param
   - Edge case: Unit B might be mid-score-entry when redirect happens — show a brief toast "Match completed by host" before navigating
2. **Player merge UI** — Backend is done (`merge_players.php`), needs frontend merge tool in players.tsx
3. **Player verification flow** — Players can verify their own phone via SMS to become "verified" (unique, unmergeable)
4. **Stats dashboard** — Show player rankings, win streaks, head-to-head records
5. **Court management** — Add/edit courts from the app (backend `add_court.php` is done, needs edit/delete)

### Known Issues to Watch For
- **PHP foreach reference bug (FIXED):** Any `foreach ($array as &$item)` loop MUST be followed by `unset($item)` before the next foreach on the same array. Without this, PHP overwrites the last element on each iteration of the next loop. This caused wrong game counts in get_leaderboard.php.
- **User ID:** Chip's current user_id is `5` (phone +19497359415). User 11 (+19497359416) is an old account. Sessions and groups should have `user_id = 5`.
- **Leaderboard JOIN fix (DEPLOYED):** Old `get_leaderboard.php` and `get_universal_sessions.php` joined `matches.session_id` to `sessions.batch_id` — but `save_scores.php` stores `sessions.id` (auto-increment) in `matches.session_id`. Fixed to join on `sessions.id`.
- **Badge logic fix (DEPLOYED):** Emojis were garbled (encoding issue), fire threshold was 3 (now 4+), diamond was unreachable after fire. Fixed: 🏆 Platinum=100%, 💎 Diamond=1 loss, 🔥 Fire=4+ wins (not if platinum), 🦃 Turkey=got scored 0 (combinable).
- **Roster query fix (DEPLOYED):** Old `get_leaderboard.php` and `get_groups.php` queried `players.group_id` directly. Fixed to use `player_group_memberships` table (universal player architecture).
- If `add_player.php` still throws unique constraint errors on `cell_phone`, verify that empty strings were converted to NULL: `UPDATE players SET cell_phone = NULL WHERE cell_phone = '';`
- `game.tsx` has `cleanPlayer()` to avoid circular JSON when saving — if you see "cyclical structure" errors, check that team objects are being cleaned.

---

## USER CONTEXT

- **User:** Chip, based in Rancho Santa Margarita, CA
- **Primary courts:** Sun and Sail (Lake Forest), The Club at Rancho Niguel (Laguna Niguel)
- **App name:** Play PB Now!
- **Brand colors:** Navy (#1b3358), Green (#87ca37)
- **Database host:** peoplestar.com, managed via phpMyAdmin
- **Player data was purged** — starting fresh with universal player architecture

---

## PREVIOUS TRANSCRIPTS (for deep context)
Located at `/mnt/transcripts/`:
1. `2026-02-17-11-48-08-playpbnow-collaboration-sync-setup.txt`
2. `2026-02-17-18-42-28-collab-scoring-implementation.txt`
3. `2026-02-17-19-41-03-collab-scoring-zero-bug-fix.txt`
4. `2026-02-17-20-47-09-collab-sync-unit-a-boss-save-fix.txt`
